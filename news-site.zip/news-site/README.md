# Daily world politics page

1. Create a free account at github.com and a new **public** repository (e.g. `world-news`).
2. Upload these files, keeping the folder structure:
   - `update_news.py`
   - `.github/workflows/daily.yml`
3. Go to **Actions** tab, enable workflows if asked, pick **Update news page**, tap **Run workflow**. This creates `index.html`.
4. Go to **Settings > Pages**, set Source to **Deploy from a branch**, branch **main**, folder **/ (root)**, Save.
5. After a minute your page is live at `https://YOUR-USERNAME.github.io/world-news/`.

It then refreshes itself every day at 06:00 UTC. Change the time in `daily.yml` (cron line).
